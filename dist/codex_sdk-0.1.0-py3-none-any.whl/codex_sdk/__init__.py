"""
codex-sdk — Unofficial Python SDK for the ChatGPT Codex backend API.

DISCLAIMER: This is an independent, community-maintained library that
reverse-engineers undocumented endpoints of chatgpt.com. It is not
affiliated with, endorsed by, or supported by OpenAI. Use is subject
to OpenAI's Terms of Use (https://openai.com/policies/terms-of-use).
Endpoints may change or break without notice.

Quickstart:
    from codex_sdk import CodexClient

    client = CodexClient().authenticate()   # opens browser on first run
    # subsequent runs load & refresh tokens automatically:
    client = CodexClient.from_saved_tokens()

    for event in client.stream("Explain quicksort"):
        ...
"""

__version__ = "0.1.0"

from .oauth import run_oauth_flow, refresh_access_token, obtain_api_key
from .storage import load_tokens, save_tokens, TokenStore
from .codex_client import (
    ReasoningEffort,
    ReasoningSummary,
    Verbosity,
    ServiceTier,
    CodexClient,
    client_from_saved_tokens,
    ModelInfo,
    ReasoningLevel,
    TextDelta,
    ReasoningDelta,
    ToolCall,
    OutputItem,
    TokenUsage,
    ResponseCompleted,
    ResponseFailed,
    CompactionResult,
    image_url,
    image_b64,
)

__all__ = [
    "CodexClient",
    "ReasoningEffort",
    "ReasoningSummary",
    "Verbosity",
    "ServiceTier",
    "client_from_saved_tokens",
    "ModelInfo",
    "ReasoningLevel",
    "TextDelta",
    "ReasoningDelta",
    "ToolCall",
    "OutputItem",
    "TokenUsage",
    "ResponseCompleted",
    "ResponseFailed",
    "CompactionResult",
    "image_url",
    "image_b64",
    "run_oauth_flow",
    "refresh_access_token",
    "obtain_api_key",
    "load_tokens",
    "save_tokens",
    "TokenStore",
]
